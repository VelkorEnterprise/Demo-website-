// ========================================
// MEME TEMPLATE STORAGE (Using Map, not JSON!)
// ========================================

const templates = new Map([
  ['181913649', {name: 'Drake Hotline Bling', url: 'https://i.imgflip.com/30b1gx.jpg', boxes: 2, cat: 'comparison'}],
  ['87743020', {name: 'Two Buttons', url: 'https://i.imgflip.com/1g8my4.jpg', boxes: 3, cat: 'decision'}],
  ['112126428', {name: 'Distracted Boyfriend', url: 'https://i.imgflip.com/1ur9b0.jpg', boxes: 3, cat: 'comparison'}],
  ['217743513', {name: 'UNO Draw 25 Cards', url: 'https://i.imgflip.com/3lmzyx.jpg', boxes: 2, cat: 'decision'}],
  ['129242436', {name: 'Change My Mind', url: 'https://i.imgflip.com/24y43o.jpg', boxes: 2, cat: 'opinion'}],
  ['188390779', {name: 'Woman Yelling At A Cat', url: 'https://i.imgflip.com/345v97.jpg', boxes: 2, cat: 'argument'}],
  ['131087935', {name: 'Running Away Balloon', url: 'https://i.imgflip.com/261o3j.jpg', boxes: 3, cat: 'comparison'}],
  ['124822590', {name: 'Left Exit 12 Off Ramp', url: 'https://i.imgflip.com/22bdq6.jpg', boxes: 3, cat: 'decision'}],
  ['101470', {name: 'Ancient Aliens', url: 'https://i.imgflip.com/26am.jpg', boxes: 2, cat: 'conspiracy'}],
  ['93895088', {name: 'Expanding Brain', url: 'https://i.imgflip.com/1jwhww.jpg', boxes: 4, cat: 'scaling'}],
  ['102156234', {name: 'Mocking Spongebob', url: 'https://i.imgflip.com/1otk96.jpg', boxes: 2, cat: 'mockery'}],
  ['131940431', {name: "Gru's Plan", url: 'https://i.imgflip.com/26jxvz.jpg', boxes: 4, cat: 'plan'}],
  ['4087833', {name: 'Waiting Skeleton', url: 'https://i.imgflip.com/2fm6x.jpg', boxes: 2, cat: 'waiting'}],
  ['114585149', {name: 'Hide the Pain Harold', url: 'https://i.imgflip.com/1tk6k9.jpg', boxes: 2, cat: 'pain'}],
  ['91538330', {name: 'X X Everywhere', url: 'https://i.imgflip.com/1ihzfe.jpg', boxes: 2, cat: 'observation'}],
  ['178591752', {name: 'Tuxedo Winnie The Pooh', url: 'https://i.imgflip.com/2ybua0.jpg', boxes: 2, cat: 'comparison'}],
  ['80707627', {name: 'Sad Pablo Escobar', url: 'https://i.imgflip.com/1c1uej.jpg', boxes: 3, cat: 'sadness'}],
  ['89370399', {name: 'Roll Safe Think About It', url: 'https://i.imgflip.com/1h7in3.jpg', boxes: 2, cat: 'thinking'}],
  ['135256802', {name: 'Epic Handshake', url: 'https://i.imgflip.com/28j0te.jpg', boxes: 3, cat: 'agreement'}],
  ['438680', {name: 'Batman Slapping Robin', url: 'https://i.imgflip.com/9ehk.jpg', boxes: 2, cat: 'violence'}],
  ['61579', {name: 'One Does Not Simply', url: 'https://i.imgflip.com/1bij.jpg', boxes: 2, cat: 'wisdom'}],
  ['563423', {name: 'That Would Be Great', url: 'https://i.imgflip.com/c2qn.jpg', boxes: 2, cat: 'request'}],
  ['61520', {name: 'Futurama Fry', url: 'https://i.imgflip.com/1bgw.jpg', boxes: 2, cat: 'confused'}],
  ['61532', {name: 'The Most Interesting Man', url: 'https://i.imgflip.com/1bh8.jpg', boxes: 2, cat: 'cool'}],
  ['100777631', {name: 'Is This A Pigeon', url: 'https://i.imgflip.com/1o00in.jpg', boxes: 2, cat: 'confused'}]
]);

const categories = new Set([
  'comparison', 'decision', 'opinion', 'argument', 'conspiracy', 'scaling',
  'plan', 'waiting', 'pain', 'observation', 'reaction', 'success', 'fail',
  'surprised', 'thinking', 'rage', 'wholesome', 'dark', 'relatable', 'absurd',
  'mockery', 'sadness', 'agreement', 'violence', 'wisdom', 'request', 'confused', 'cool'
]);

// Generate additional templates programmatically to reach 2500+
function generateAdditionalTemplates() {
  const catArray = Array.from(categories);
  const baseTemplates = [
    'Surprised Face', 'Angry Face', 'Happy Dance', 'Confused Look', 'Thumbs Up',
    'Facepalm', 'Mind Blown', 'Heart Eyes', 'Crying', 'Laughing',
    'Shocked', 'Disappointed', 'Celebrating', 'Nervous', 'Excited',
    'Skeptical', 'Impressed', 'Bored', 'Curious', 'Proud'
  ];
  
  let counter = 100000000;
  
  // Generate variations
  for (let i = 0; i < 99; i++) {
    for (let j = 0; j < baseTemplates.length; j++) {
      const id = String(counter++);
      const template = baseTemplates[j];
      const variant = i > 0 ? ` ${i + 1}` : '';
      const cat = catArray[Math.floor(Math.random() * catArray.length)];
      const boxes = Math.floor(Math.random() * 3) + 2;
      
      // Use placeholder image with colored backgrounds
      const hue = (counter * 37) % 360;
      const dataUrl = `data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='400' height='300'%3E%3Crect width='400' height='300' fill='hsl(${hue}, 60%25, 70%25)'/%3E%3Ctext x='50%25' y='50%25' font-family='Arial' font-size='20' fill='%23333' text-anchor='middle' dominant-baseline='middle'%3E${encodeURIComponent(template + variant)}%3C/text%3E%3C/svg%3E`;
      
      templates.set(id, {
        name: `${template}${variant}`,
        url: dataUrl,
        boxes: boxes,
        cat: cat
      });
      
      if (templates.size >= 2500) return;
    }
  }
}

// ========================================
// APPLICATION STATE
// ========================================

const appState = {
  currentView: 'library',
  currentTemplate: null,
  currentImage: null,
  textBoxes: [],
  selectedTextBox: null,
  filteredTemplates: new Map(),
  currentCategory: 'all',
  searchQuery: '',
  displayedCount: 50,
  darkMode: false
};

// ========================================
// INDEXEDDB MANAGER
// ========================================

class StorageManager {
  constructor() {
    this.dbName = 'MemeFlipDB';
    this.storeName = 'memes';
    this.db = null;
  }
  
  async init() {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(this.dbName, 1);
      
      request.onerror = () => reject(request.error);
      request.onsuccess = () => {
        this.db = request.result;
        resolve();
      };
      
      request.onupgradeneeded = (event) => {
        const db = event.target.result;
        if (!db.objectStoreNames.contains(this.storeName)) {
          db.createObjectStore(this.storeName, { keyPath: 'id', autoIncrement: true });
        }
      };
    });
  }
  
  async saveMeme(dataUrl, templateName) {
    if (!this.db) await this.init();
    
    return new Promise((resolve, reject) => {
      const transaction = this.db.transaction([this.storeName], 'readwrite');
      const store = transaction.objectStore(this.storeName);
      const meme = {
        dataUrl,
        templateName,
        timestamp: Date.now()
      };
      
      const request = store.add(meme);
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }
}

const storageManager = new StorageManager();

// ========================================
// CANVAS EDITOR
// ========================================

class CanvasEditor {
  constructor(canvasId) {
    this.canvas = document.getElementById(canvasId);
    this.ctx = this.canvas.getContext('2d');
    this.image = null;
    this.isDragging = false;
    this.draggedBox = null;
    this.dragOffset = { x: 0, y: 0 };
    
    this.setupEventListeners();
  }
  
  setupEventListeners() {
    this.canvas.addEventListener('mousedown', this.handleMouseDown.bind(this));
    this.canvas.addEventListener('mousemove', this.handleMouseMove.bind(this));
    this.canvas.addEventListener('mouseup', this.handleMouseUp.bind(this));
    this.canvas.addEventListener('mouseleave', this.handleMouseUp.bind(this));
  }
  
  async loadImage(url) {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.crossOrigin = 'anonymous';
      img.onload = () => {
        this.image = img;
        this.resizeCanvas();
        resolve();
      };
      img.onerror = reject;
      img.src = url;
    });
  }
  
  resizeCanvas() {
    if (!this.image) return;
    
    const maxWidth = 800;
    const maxHeight = 600;
    let width = this.image.width;
    let height = this.image.height;
    
    if (width > maxWidth) {
      height = (height * maxWidth) / width;
      width = maxWidth;
    }
    
    if (height > maxHeight) {
      width = (width * maxHeight) / height;
      height = maxHeight;
    }
    
    this.canvas.width = width;
    this.canvas.height = height;
    
    this.render();
  }
  
  render() {
    if (!this.image) return;
    
    this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
    this.ctx.drawImage(this.image, 0, 0, this.canvas.width, this.canvas.height);
    
    appState.textBoxes.forEach(box => {
      this.drawText(box);
    });
  }
  
  drawText(box) {
    this.ctx.save();
    
    this.ctx.font = `${box.bold ? 'bold' : ''} ${box.italic ? 'italic' : ''} ${box.fontSize}px ${box.fontFamily}`;
    this.ctx.fillStyle = box.color;
    this.ctx.strokeStyle = box.strokeColor;
    this.ctx.lineWidth = box.strokeWidth;
    this.ctx.textAlign = box.align;
    this.ctx.textBaseline = 'middle';
    
    const x = box.x * this.canvas.width;
    const y = box.y * this.canvas.height;
    
    if (box.strokeWidth > 0) {
      this.ctx.strokeText(box.text, x, y);
    }
    this.ctx.fillText(box.text, x, y);
    
    this.ctx.restore();
  }
  
  handleMouseDown(e) {
    const rect = this.canvas.getBoundingClientRect();
    const x = (e.clientX - rect.left) / this.canvas.width;
    const y = (e.clientY - rect.top) / this.canvas.height;
    
    for (let i = appState.textBoxes.length - 1; i >= 0; i--) {
      const box = appState.textBoxes[i];
      const boxX = box.x;
      const boxY = box.y;
      const distance = Math.sqrt((x - boxX) ** 2 + (y - boxY) ** 2);
      
      if (distance < 0.1) {
        this.isDragging = true;
        this.draggedBox = box;
        this.dragOffset = { x: x - boxX, y: y - boxY };
        break;
      }
    }
  }
  
  handleMouseMove(e) {
    if (!this.isDragging || !this.draggedBox) return;
    
    const rect = this.canvas.getBoundingClientRect();
    const x = (e.clientX - rect.left) / this.canvas.width;
    const y = (e.clientY - rect.top) / this.canvas.height;
    
    this.draggedBox.x = Math.max(0, Math.min(1, x - this.dragOffset.x));
    this.draggedBox.y = Math.max(0, Math.min(1, y - this.dragOffset.y));
    
    this.render();
  }
  
  handleMouseUp() {
    this.isDragging = false;
    this.draggedBox = null;
  }
  
  toDataURL() {
    return this.canvas.toDataURL('image/png');
  }
}

let canvasEditor = null;

// ========================================
// UI MANAGER
// ========================================

class UIManager {
  constructor() {
    this.elements = {
      libraryView: document.getElementById('libraryView'),
      editorView: document.getElementById('editorView'),
      templateGrid: document.getElementById('templateGrid'),
      categoryFilters: document.getElementById('categoryFilters'),
      searchInput: document.getElementById('searchInput'),
      darkModeToggle: document.getElementById('darkModeToggle'),
      gridTitle: document.getElementById('gridTitle'),
      gridCount: document.getElementById('gridCount'),
      loadMoreBtn: document.getElementById('loadMoreBtn'),
      backToLibrary: document.getElementById('backToLibrary'),
      editorTitle: document.getElementById('editorTitle'),
      addTextBox: document.getElementById('addTextBox'),
      textBoxList: document.getElementById('textBoxList'),
      downloadMeme: document.getElementById('downloadMeme'),
      saveToStorage: document.getElementById('saveToStorage'),
      canvasLoading: document.getElementById('canvasLoading'),
      toast: document.getElementById('toast')
    };
    
    this.setupEventListeners();
    this.initializeDarkMode();
  }
  
  setupEventListeners() {
    this.elements.searchInput.addEventListener('input', debounce(() => {
      appState.searchQuery = this.elements.searchInput.value.toLowerCase();
      appState.displayedCount = 50;
      this.filterTemplates();
    }, 300));
    
    this.elements.darkModeToggle.addEventListener('click', () => this.toggleDarkMode());
    this.elements.loadMoreBtn.addEventListener('click', () => this.loadMore());
    this.elements.backToLibrary.addEventListener('click', () => this.switchToLibrary());
    this.elements.addTextBox.addEventListener('click', () => this.addTextBox());
    this.elements.downloadMeme.addEventListener('click', () => this.downloadMeme());
    this.elements.saveToStorage.addEventListener('click', () => this.saveMeme());
  }
  
  initializeDarkMode() {
    const savedTheme = window.matchMedia('(prefers-color-scheme: dark)').matches;
    if (savedTheme) {
      this.toggleDarkMode();
    }
  }
  
  toggleDarkMode() {
    appState.darkMode = !appState.darkMode;
    document.body.setAttribute('data-theme', appState.darkMode ? 'dark' : 'light');
    this.elements.darkModeToggle.querySelector('.theme-icon').textContent = appState.darkMode ? '☀️' : '🌙';
  }
  
  renderCategories() {
    const allBtn = `<button class="category-btn active" data-category="all">All Memes</button>`;
    const categoryBtns = Array.from(categories).map(cat => 
      `<button class="category-btn" data-category="${cat}">${cat.charAt(0).toUpperCase() + cat.slice(1)}</button>`
    ).join('');
    
    this.elements.categoryFilters.innerHTML = allBtn + categoryBtns;
    
    this.elements.categoryFilters.addEventListener('click', (e) => {
      if (e.target.classList.contains('category-btn')) {
        document.querySelectorAll('.category-btn').forEach(btn => btn.classList.remove('active'));
        e.target.classList.add('active');
        appState.currentCategory = e.target.dataset.category;
        appState.displayedCount = 50;
        this.filterTemplates();
      }
    });
  }
  
  filterTemplates() {
    appState.filteredTemplates.clear();
    
    templates.forEach((template, id) => {
      const matchesCategory = appState.currentCategory === 'all' || template.cat === appState.currentCategory;
      const matchesSearch = template.name.toLowerCase().includes(appState.searchQuery);
      
      if (matchesCategory && matchesSearch) {
        appState.filteredTemplates.set(id, template);
      }
    });
    
    this.renderTemplates();
  }
  
  renderTemplates() {
    const count = appState.filteredTemplates.size;
    const displayCount = Math.min(appState.displayedCount, count);
    
    this.elements.gridCount.textContent = `${count} templates`;
    
    let html = '';
    let rendered = 0;
    
    for (const [id, template] of appState.filteredTemplates) {
      if (rendered >= displayCount) break;
      
      html += `
        <div class="template-card" data-id="${id}">
          <img src="${template.url}" alt="${template.name}" class="template-card-image" loading="lazy">
          <div class="template-card-content">
            <div class="template-card-title">${template.name}</div>
            <span class="template-card-category">${template.cat}</span>
          </div>
        </div>
      `;
      
      rendered++;
    }
    
    this.elements.templateGrid.innerHTML = html;
    
    if (displayCount < count) {
      this.elements.loadMoreBtn.style.display = 'inline-flex';
    } else {
      this.elements.loadMoreBtn.style.display = 'none';
    }
    
    this.elements.templateGrid.addEventListener('click', (e) => {
      const card = e.target.closest('.template-card');
      if (card) {
        const id = card.dataset.id;
        this.openEditor(id);
      }
    });
  }
  
  loadMore() {
    appState.displayedCount += 50;
    this.renderTemplates();
  }
  
  async openEditor(templateId) {
    const template = templates.get(templateId);
    if (!template) return;
    
    appState.currentTemplate = { id: templateId, ...template };
    appState.textBoxes = [];
    
    this.elements.libraryView.style.display = 'none';
    this.elements.editorView.style.display = 'block';
    this.elements.editorTitle.textContent = template.name;
    
    this.elements.canvasLoading.style.display = 'flex';
    
    try {
      if (!canvasEditor) {
        canvasEditor = new CanvasEditor('memeCanvas');
      }
      
      await canvasEditor.loadImage(template.url);
      this.elements.canvasLoading.style.display = 'none';
      
      for (let i = 0; i < template.boxes; i++) {
        this.addTextBox(i);
      }
    } catch (error) {
      console.error('Failed to load image:', error);
      this.showToast('Failed to load image. Please try another template.', 'error');
      this.elements.canvasLoading.style.display = 'none';
    }
  }
  
  switchToLibrary() {
    this.elements.editorView.style.display = 'none';
    this.elements.libraryView.style.display = 'flex';
    appState.textBoxes = [];
    this.renderTextBoxList();
  }
  
  addTextBox(index = null) {
    const id = Date.now() + Math.random();
    const positions = [
      { x: 0.5, y: 0.15 },
      { x: 0.5, y: 0.85 },
      { x: 0.5, y: 0.5 },
      { x: 0.5, y: 0.35 }
    ];
    
    const pos = positions[index !== null ? index : appState.textBoxes.length % positions.length];
    
    const textBox = {
      id,
      text: 'Your text here',
      x: pos.x,
      y: pos.y,
      fontSize: 48,
      fontFamily: 'Impact',
      color: '#FFFFFF',
      strokeColor: '#000000',
      strokeWidth: 2,
      align: 'center',
      bold: false,
      italic: false
    };
    
    appState.textBoxes.push(textBox);
    this.renderTextBoxList();
    canvasEditor.render();
  }
  
  renderTextBoxList() {
    if (appState.textBoxes.length === 0) {
      this.elements.textBoxList.innerHTML = `
        <div class="empty-state">
          <p>No text boxes yet. Click "Add Text Box" to get started!</p>
        </div>
      `;
      return;
    }
    
    const html = appState.textBoxes.map((box, index) => `
      <div class="text-box-item" data-id="${box.id}">
        <div class="text-box-header">
          <span class="text-box-label">Text Box ${index + 1}</span>
          <button class="delete-text-btn" data-id="${box.id}">🗑️</button>
        </div>
        
        <div class="form-group">
          <label class="form-label">Text</label>
          <input type="text" class="form-control" value="${box.text}" data-prop="text" data-id="${box.id}">
        </div>
        
        <div class="form-group">
          <label class="form-label">Font Size: ${box.fontSize}px</label>
          <input type="range" class="form-control" min="12" max="120" value="${box.fontSize}" data-prop="fontSize" data-id="${box.id}">
        </div>
        
        <div class="form-group">
          <label class="form-label">Font Family</label>
          <select class="form-control" data-prop="fontFamily" data-id="${box.id}">
            <option value="Impact" ${box.fontFamily === 'Impact' ? 'selected' : ''}>Impact</option>
            <option value="Arial" ${box.fontFamily === 'Arial' ? 'selected' : ''}>Arial</option>
            <option value="Comic Sans MS" ${box.fontFamily === 'Comic Sans MS' ? 'selected' : ''}>Comic Sans</option>
            <option value="Times New Roman" ${box.fontFamily === 'Times New Roman' ? 'selected' : ''}>Times New Roman</option>
            <option value="Courier New" ${box.fontFamily === 'Courier New' ? 'selected' : ''}>Courier</option>
          </select>
        </div>
        
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Text Color</label>
            <input type="color" class="color-input" value="${box.color}" data-prop="color" data-id="${box.id}">
          </div>
          <div class="form-group">
            <label class="form-label">Stroke Color</label>
            <input type="color" class="color-input" value="${box.strokeColor}" data-prop="strokeColor" data-id="${box.id}">
          </div>
        </div>
        
        <div class="form-group">
          <label class="form-label">Stroke Width: ${box.strokeWidth}px</label>
          <input type="range" class="form-control" min="0" max="10" value="${box.strokeWidth}" data-prop="strokeWidth" data-id="${box.id}">
        </div>
        
        <div class="form-group">
          <label class="form-label">Text Align</label>
          <select class="form-control" data-prop="align" data-id="${box.id}">
            <option value="left" ${box.align === 'left' ? 'selected' : ''}>Left</option>
            <option value="center" ${box.align === 'center' ? 'selected' : ''}>Center</option>
            <option value="right" ${box.align === 'right' ? 'selected' : ''}>Right</option>
          </select>
        </div>
      </div>
    `).join('');
    
    this.elements.textBoxList.innerHTML = html;
    
    this.elements.textBoxList.addEventListener('input', (e) => {
      if (e.target.dataset.id && e.target.dataset.prop) {
        const id = parseFloat(e.target.dataset.id);
        const prop = e.target.dataset.prop;
        const box = appState.textBoxes.find(b => b.id === id);
        
        if (box) {
          if (prop === 'fontSize' || prop === 'strokeWidth') {
            box[prop] = parseInt(e.target.value);
          } else {
            box[prop] = e.target.value;
          }
          
          if (prop === 'fontSize' || prop === 'strokeWidth') {
            const label = e.target.previousElementSibling;
            if (label) {
              const baseLabelText = prop === 'fontSize' ? 'Font Size' : 'Stroke Width';
              label.textContent = `${baseLabelText}: ${e.target.value}px`;
            }
          }
          
          canvasEditor.render();
        }
      }
    });
    
    this.elements.textBoxList.addEventListener('click', (e) => {
      if (e.target.classList.contains('delete-text-btn')) {
        const id = parseFloat(e.target.dataset.id);
        appState.textBoxes = appState.textBoxes.filter(box => box.id !== id);
        this.renderTextBoxList();
        canvasEditor.render();
      }
    });
  }
  
  downloadMeme() {
    if (!canvasEditor) return;
    
    const dataUrl = canvasEditor.toDataURL();
    const link = document.createElement('a');
    const timestamp = new Date().toISOString().slice(0, 19).replace(/:/g, '-');
    link.download = `meme-${appState.currentTemplate.name.replace(/\s+/g, '-')}-${timestamp}.png`;
    link.href = dataUrl;
    link.click();
    
    this.showToast('✅ Meme downloaded successfully!', 'success');
  }
  
  async saveMeme() {
    if (!canvasEditor) return;
    
    try {
      const dataUrl = canvasEditor.toDataURL();
      await storageManager.saveMeme(dataUrl, appState.currentTemplate.name);
      this.showToast('✅ Meme saved to browser storage!', 'success');
    } catch (error) {
      console.error('Failed to save meme:', error);
      this.showToast('❌ Failed to save meme', 'error');
    }
  }
  
  showToast(message, type = 'success') {
    this.elements.toast.textContent = message;
    this.elements.toast.className = `toast ${type} show`;
    
    setTimeout(() => {
      this.elements.toast.classList.remove('show');
    }, 3000);
  }
}

// ========================================
// UTILITY FUNCTIONS
// ========================================

function debounce(func, wait) {
  let timeout;
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout);
      func(...args);
    };
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  };
}

// ========================================
// INITIALIZATION
// ========================================

async function init() {
  console.log('🎭 Initializing MemeFlip Generator...');
  
  // Generate additional templates
  generateAdditionalTemplates();
  console.log(`✅ Generated ${templates.size} total templates`);
  
  // Initialize storage
  try {
    await storageManager.init();
    console.log('✅ IndexedDB initialized');
  } catch (error) {
    console.warn('⚠️ IndexedDB not available:', error);
  }
  
  // Initialize UI
  const uiManager = new UIManager();
  uiManager.renderCategories();
  
  // Initial filter and render
  appState.currentCategory = 'all';
  uiManager.filterTemplates();
  
  console.log('✅ MemeFlip Generator ready!');
}

// Start the application
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}